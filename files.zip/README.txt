=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
CIS 120 Game Project README
PennKey: _______
=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=

===================
=: Core Concepts :=
===================

- List the four core concepts, the features they implement, and why each feature
  is an approprate use of the concept. You may copy and paste from your proposal
  document if you did not change the features you are implementing.

  1. Inheritance, Subtyping
  
	I implemented Powerups with this concept. Powerups was a worthy superclass because although
	the three powerups had different effects, they were the same in the way they interacted with
	Player. All of them would have their effect called once they intersected a Player.
	As a result, through dynamic dispatch, I was able to call the specific effect of a powerup
	in an ArrayList of various different powerups.
	
  2. Modeling state using collections
  	Collections were exteremely crucial in this game. I used ArrayLists to store the meteors on the
  	field, the powerups on the field, and the missiles of both players. I chose an ArrayList
  	so that I could iterate through it and do whatever need to be done (draw, see if they collide
  	with something, etc)

  3. Testable Component
	Much of the storage of information was contained in Player. Player stored his health,
	his bullets, and powerups were associated with a specific player. As a result, I tested
	these components with JUnit tests. I was able to verify that my code was performing as 
	expected through the testing done on Player.
	
  4. I/O
	I/O was used to store high scores in this game. I wrote the name of the winning player, the
	number of missiles fired by that player, and the number of powerups used by that player. The 
	high score displays the players with the lowest number of missiles fired. This required writing
	the necessary information to a text file and reading that text file, parsing through it and
	displaying it in a meaningful way.

=========================
=: Your Implementation :=
=========================

- Provide an overview of each of the classes in your code, and what their
  function is in the overall game.
  
	-BoostHealth is a powerup that increases the health of the player.
	-BoostSize is a powerup that increases the size of the missiles of the player.
	-BoostSpeed is a powerup that increases the speed of the layer.
	-Bullet is the superclass of Missile1 and Missile2 and allows there to be just a single
	collection for both missiles of a player.
	-Direction is as given, specifies orientations of objects
	-Game contains the main method and sets up the frame
	-GameCourt creates the area that the game takes place in. It defines some of the interactions
	-GameObj is the superclass of all objects in the game and implements values such as 
	the object's position, velocity, movement, etc.
	-Health creates the health object that stores a health level as an int.
	-Meteor creates meteor objects that spawn in the game
	-Missile1 creates red missiles that shoot straight in the game
	-Missile2 creates blue missiles that move at angles in the game
	-Player stores much of the game information. There is an ArrayList of the player's bullets and a 
	Health object that is the player's health
	-PlayerTest is the JUnit test file
	-Powerup is the superclass of the three powerups and defines common interactions between them. It
	allows dynamic dispatch to occur.

- Revisit your proposal document. What components of your plan did you end up
  keeping? What did you have to change? Why?
	-I ended up keeping my plan to create two types of missiles, the health class, the player class,
	the meteor class, and the powerups. I changed the GravityBullet because I felt like it 
	did not add anything to the game. I also altered the way I envisioned implementing collections 
	that stored the Bullets. I decided to associate them with a Player, instead of putting them
	separately in GameCourt.

- Were there any significant stumbling blocks while you were implementing your
  game (related to your design, or otherwise)?

	There was one major stumbling block. I had issues with not concurrently iterating
	through a collection and modifying it (NoConcurrentModificationException). I ended up 
	creating two new methods that would remove it from the ArrayList itself, as opposed to
	from the Iterator like I was attempting. Apart from that, I had trouble with bugs in I/O, but
	they were solved after I reviewed I/O objects more carefully.

- Evaluate your design. Is there a good separation of functionality? How well is
  private state encapsulated? What would you refactor, if given the chance?
	
	I think that there was relatively good separation of functionality. The player brings 
	together much of the game, and the methods in Player call on methods in classes like
	Powerup and Health to produce an effect. If given the chance, I would refactor the 
	way I designed Missiles. I think that instead of handling the interaction
	of missiles in GameCourt, I would handle them instead in the Bullet class. That would provide
	more encapsulation.


========================
=: External Resources :=
========================

- Cite any external resources (libraries, images, tutorials, etc.) that you may
  have used while implementing your game.

Images:
http://home.versatel.nl/epragt/tutorials/photoshop/shapesandobjects/laserbeam/images/step00.gif
http://steamcommunity.com/sharedfiles/filedetails/?id=188079787
http://www.archjrc.com/clipart/images/halloweenkids/wizard1.png
https://www.pinterest.com/pin/368380444494504086/

I used the Comparator library as well.
http://examples.javacodegeeks.com/core-java/util/comparator/java-comparator-example/
